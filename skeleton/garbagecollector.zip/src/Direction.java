/**
 * Az iranyokat hazarozza meg.
 */
public enum Direction {
	/**
	 * Fel
	 */
	UP,
	/**
	 * Le
	 */
	DOWN,
	/**
	 * Balra
	 */
	LEFT,
	/**
	 * Jobbra
	 */
	RIGHT
}
