/**
 * Az egyes mezok sikossagat hatarozza meg.
 */
public enum Modifier {
    /**
     * Tiszta
     */
    REGULAR,
    /**
     * Olajos
     */
    OIL,
    /**
     * Mezes
     */
    HONEY
}